<?php

declare(strict_types=1);

namespace App\Modules\Scolarite\Filament\Resources\ClasseResource\Pages;

use App\Modules\Scolarite\Filament\Resources\ClasseResource;
use Filament\Resources\Pages\CreateRecord;

class CreateClasse extends CreateRecord
{
    protected static string $resource = ClasseResource::class;
}
