<?php

declare(strict_types=1);

namespace App\Modules\Scolarite\Filament\Resources;

use App\Modules\Scolarite\Contracts\PaiementServiceContract;
use App\Modules\Scolarite\Filament\Resources\PaiementResource\Pages;
use App\Modules\Scolarite\Models\Paiement;
use BackedEnum;
use Filament\Actions\Action;
use Filament\Forms\Components\Textarea;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use UnitEnum;

/**
 * Registre des versements — lecture seule. Un versement se crée uniquement
 * via l'action "Encaisser un versement" sur la fiche d'une inscription
 * (voir InscriptionResource\Pages\ViewInscription), jamais ici directement.
 */
class PaiementResource extends Resource
{
    protected static ?string $model = Paiement::class;

    protected static string|BackedEnum|null $navigationIcon = 'heroicon-o-credit-card';

    protected static string|UnitEnum|null $navigationGroup = 'Scolarité';

    protected static ?string $navigationLabel = 'Versements';

    protected static ?string $modelLabel = 'versement';

    protected static ?string $pluralModelLabel = 'versements';

    public static function canCreate(): bool
    {
        return false;
    }

    public static function canEdit($record): bool
    {
        return false;
    }

    public static function table(Table $table): Table
    {
        return $table
            ->query(Paiement::query()->with(['inscription.eleve']))
            ->columns([
                Tables\Columns\TextColumn::make('numero_recu')->label('N° reçu')->searchable()->sortable(),

                Tables\Columns\TextColumn::make('inscription.eleve.nom')
                    ->label('Élève')
                    ->formatStateUsing(fn (Paiement $record): string => trim("{$record->inscription?->eleve?->prenom} {$record->inscription?->eleve?->nom}"))
                    ->searchable(['inscription.eleve.nom', 'inscription.eleve.prenom']),

                Tables\Columns\TextColumn::make('montant')->label('Montant')->money('XAF')->sortable(),

                Tables\Columns\TextColumn::make('mode')
                    ->label('Mode')
                    ->badge()
                    ->formatStateUsing(fn (string $s): string => match ($s) {
                        'especes' => 'Espèces',
                        'bancaire' => 'Bancaire',
                        'mobile_money' => 'Mobile Money',
                        default => $s,
                    }),

                Tables\Columns\TextColumn::make('statut')
                    ->label('Statut')
                    ->badge()
                    ->formatStateUsing(fn (string $s): string => $s === 'valide' ? 'Valide' : 'Annulé')
                    ->color(fn (string $s): string => $s === 'valide' ? 'success' : 'danger'),

                Tables\Columns\TextColumn::make('created_at')->label('Encaissé le')->dateTime('d/m/Y H:i')->sortable(),
            ])
            ->filters([
                Tables\Filters\SelectFilter::make('statut')->options([
                    'valide' => 'Valide',
                    'annule' => 'Annulé',
                ]),
                Tables\Filters\SelectFilter::make('mode')->options([
                    'especes' => 'Espèces',
                    'bancaire' => 'Bancaire',
                    'mobile_money' => 'Mobile Money',
                ]),
            ])
            ->actions([
                Action::make('annuler')
                    ->label('Annuler')
                    ->icon('heroicon-o-x-circle')
                    ->color('danger')
                    ->visible(fn (Paiement $record) => $record->statut === 'valide')
                    ->requiresConfirmation()
                    ->form([
                        Textarea::make('motif')->label('Motif d’annulation')->required(),
                    ])
                    ->action(fn (Paiement $record, array $data) => app(PaiementServiceContract::class)->annulerPaiement($record->id, $data['motif'])),
            ])
            ->defaultSort('created_at', 'desc');
    }

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListPaiements::route('/'),
        ];
    }
}
