<?php

declare(strict_types=1);

namespace App\Modules\Scolarite\Filament\Resources\CategorieFraisResource\Pages;

use App\Modules\Scolarite\Contracts\FraisServiceContract;
use App\Modules\Scolarite\Filament\Resources\CategorieFraisResource;
use Filament\Resources\Pages\EditRecord;

class EditCategorieFrais extends EditRecord
{
    protected static string $resource = CategorieFraisResource::class;

    protected function handleRecordUpdate(\Illuminate\Database\Eloquent\Model $record, array $data): \Illuminate\Database\Eloquent\Model
    {
        app(FraisServiceContract::class)->modifierCategorie($record->id, $data['nom']);

        return $record->fresh();
    }
}
