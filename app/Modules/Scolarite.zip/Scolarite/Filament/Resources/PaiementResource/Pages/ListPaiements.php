<?php

declare(strict_types=1);

namespace App\Modules\Scolarite\Filament\Resources\PaiementResource\Pages;

use App\Modules\Scolarite\Filament\Resources\PaiementResource;
use Filament\Resources\Pages\ListRecords;

class ListPaiements extends ListRecords
{
    protected static string $resource = PaiementResource::class;

    protected function getHeaderActions(): array
    {
        return [];
    }
}
