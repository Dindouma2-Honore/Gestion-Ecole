<?php

declare(strict_types=1);

namespace App\Modules\Scolarite\Contracts;

interface InscriptionServiceInterface
{
    /**
     * Orchestre, dans une seule transaction : création de l'inscription
     * (statut initial `en_attente_versement`) → calcul des frais dus (frais
     * de scolarité via la grille tarifaire + frais divers sélectionnés) →
     * génération et envoi par e-mail de la facture provisoire au parent
     * payeur. Ne dépend plus d'aucun module Finances : tout le circuit de
     * facturation est interne à Scolarité (voir FraisServiceContract,
     * FactureServiceInterface, PaiementServiceContract).
     *
     * @param  array<int>  $fraisDiversIds  identifiants des frais divers
     *                                      (cantine, tenues...) choisis par le parent, en plus
     *                                      des frais de scolarité (toujours appliqués).
     */
    public function inscrire(int $eleveId, int $classeId, int $anneeScolaireId, array $fraisDiversIds = []): int;

    /** Même circuit que inscrire(), avec le type d'inscription "reinscription". */
    public function reinscrire(int $eleveId, int $classeId, int $anneeScolaireId, array $fraisDiversIds = []): int;

    /**
     * Crée (si besoin) le dossier élève et le dossier parent, les lie, puis
     * démarre l'inscription via inscrire() dans la même transaction.
     */
    public function preparerEtInscrire(
        ?int $eleveId,
        array $eleve,
        ?int $parentId,
        array $parent,
        string $lienParente,
        int $classeId,
        int $anneeScolaireId,
        array $fraisDiversIds = [],
    ): int;

    /**
     * Appelée une fois le versement confirmé (reste à payer global de
     * l'inscription tombé à 0, voir PaiementServiceContract) : passe
     * l'inscription au statut `active` et déclenche la génération de la
     * facture définitive.
     */
    public function activerApresVersement(int $inscriptionId): void;

    public function annulerInscription(int $inscriptionId, string $motif): void;

    public function estInscrit(int $eleveId, int $anneeScolaireId): bool;

    /**
     * Reste à payer global de l'inscription (voir
     * PaiementServiceContract::getResteAPayer()) — c'est la valeur affichée
     * partout où l'ancien contrat renvoyait 0.0 en attendant le module
     * Finances : ce n'est plus nécessaire, la facturation étant désormais
     * portée par Scolarité elle-même.
     */
    public function getFraisRestants(int $inscriptionId): float;
}
