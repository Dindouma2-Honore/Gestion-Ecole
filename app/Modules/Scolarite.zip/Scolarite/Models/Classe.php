<?php

declare(strict_types=1);

namespace App\Modules\Scolarite\Models;

use App\Modules\Socle\Contracts\RattacheAAnneeScolaire;
use App\Modules\Socle\Contracts\ScopedByNiveau;
use App\Modules\Socle\Scopes\NiveauScope;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Classe extends Model implements RattacheAAnneeScolaire, ScopedByNiveau
{
    protected $fillable = [
        'nom', 'niveau_id', 'annee_scolaire_id', 'capacite_max', 'professeur_principal_id',
    ];

    protected static function booted(): void
    {
        // Directeur/Enseignant : ne voient que les classes de leur niveau
        // (Socle\Scopes\NiveauScope — fail-closed si niveau_id mal configuré).
        static::addGlobalScope(new NiveauScope);
    }

    public function getAnneeScolaireId(): int
    {
        return (int) $this->annee_scolaire_id;
    }

    public function getNiveauScopeColumn(): string
    {
        return 'niveau_id';
    }

    public function inscriptions(): HasMany
    {
        return $this->hasMany(Inscription::class);
    }

    /**
     * Tarifs de "Frais de scolarité" (inscription, tranche 1, tranche 2)
     * définis pour cette classe — un montant par frais et par année
     * scolaire. Le montant des frais divers (cantine, tenues...) ne varie
     * jamais par classe, voir Frais::montant.
     */
    public function grilleTarifaire(): HasMany
    {
        return $this->hasMany(GrilleTarifaire::class);
    }

    // niveau (Socle), annee_scolaire (Socle), professeur_principal (RH) :
    // autres modules -> pas de relation Eloquent directe.
}
