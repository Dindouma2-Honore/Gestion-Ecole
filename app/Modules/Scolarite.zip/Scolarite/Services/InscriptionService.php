<?php

declare(strict_types=1);

namespace App\Modules\Scolarite\Services;

use App\Modules\Scolarite\Contracts\ClasseServiceInterface;
use App\Modules\Scolarite\Contracts\FactureServiceInterface;
use App\Modules\Scolarite\Contracts\FraisServiceContract;
use App\Modules\Scolarite\Contracts\InscriptionServiceInterface;
use App\Modules\Scolarite\Contracts\PaiementServiceContract;
use App\Modules\Scolarite\Exceptions\CapaciteClasseDepasseeException;
use App\Modules\Scolarite\Exceptions\DoubleInscriptionException;
use App\Modules\Scolarite\Exceptions\EleveIntrouvableException;
use App\Modules\Scolarite\Exceptions\MotifAnnulationRequisException;
use App\Modules\Scolarite\Exceptions\ParentPayeurInvalideException;
use App\Modules\Scolarite\Models\Eleve;
use App\Modules\Scolarite\Models\FraisEleve;
use App\Modules\Scolarite\Models\Inscription;
use App\Modules\Scolarite\Models\ParentTuteur;
use App\Modules\Socle\Contracts\AuditServiceContract;
use Illuminate\Support\Facades\DB;

/**
 * Toute la facturation d'une inscription (frais, factures, versements) est
 * désormais interne à Scolarité — voir Module 5 §1 : "l'inscription ne va
 * plus jusqu'au module Finances". InscriptionService orchestre
 * FraisServiceContract et FactureServiceInterface directement ; il n'existe
 * plus de port externe ni d'état intermédiaire "en_cours" en attente d'un
 * autre module.
 */
class InscriptionService implements InscriptionServiceInterface
{
    public function __construct(
        private readonly ClasseServiceInterface $classeService,
        private readonly AuditServiceContract $auditService,
        private readonly FactureServiceInterface $factureService,
        private readonly FraisServiceContract $fraisService,
    ) {}

    public function inscrire(int $eleveId, int $classeId, int $anneeScolaireId, array $fraisDiversIds = []): int
    {
        return $this->creerInscription($eleveId, $classeId, $anneeScolaireId, $fraisDiversIds, 'inscription');
    }

    public function reinscrire(int $eleveId, int $classeId, int $anneeScolaireId, array $fraisDiversIds = []): int
    {
        return $this->creerInscription($eleveId, $classeId, $anneeScolaireId, $fraisDiversIds, 'reinscription');
    }

    private function creerInscription(int $eleveId, int $classeId, int $anneeScolaireId, array $fraisDiversIds, string $type): int
    {
        return DB::transaction(function () use ($eleveId, $classeId, $anneeScolaireId, $fraisDiversIds, $type) {

            $eleve = Eleve::with('parentsTuteurs')->find($eleveId);

            if (! $eleve) {
                throw EleveIntrouvableException::pourId($eleveId);
            }

            if ($this->estInscrit($eleveId, $anneeScolaireId)) {
                throw new DoubleInscriptionException($eleveId, $anneeScolaireId);
            }

            if ($this->classeService->getPlacesRestantes($classeId) <= 0) {
                throw new CapaciteClasseDepasseeException($classeId);
            }

            // La facture provisoire est envoyée automatiquement par e-mail :
            // il faut donc un parent payeur joignable dès la création de
            // l'inscription (même contrôle que l'ancienne préinscription
            // avec facture, désormais systématique).
            $parent = $eleve->parentsTuteurs->firstWhere('pivot.responsable_paiement', true)
                ?? $eleve->parentsTuteurs->first();

            if (! $parent || ! filter_var($parent->email, FILTER_VALIDATE_EMAIL)) {
                throw new ParentPayeurInvalideException;
            }

            // 1. Créer l'inscription — statut initial toujours
            // `en_attente_versement` (la contrainte unique en base empêche
            // le doublon élève/année).
            $inscription = Inscription::create([
                'eleve_id' => $eleveId,
                'classe_id' => $classeId,
                'annee_scolaire_id' => $anneeScolaireId,
                'type' => $type,
                'date_inscription' => now(),
                'statut' => 'en_attente_versement',
            ]);

            $eleve->update(['statut' => 'inscrit']);

            // 2. Résoudre et attacher les frais dus (scolarité via la
            // grille + frais divers sélectionnés).
            $this->fraisService->attacherFraisPourInscription($inscription->id, $classeId, $anneeScolaireId, $fraisDiversIds);

            // 3. Journaliser via le Socle — jamais d'écriture directe dans
            // la table audits. Événement système routinier (pas une
            // annulation) : enregistrer(), pas enregistrerAvecMotif() —
            // voir AuditServiceContract.
            $this->auditService->enregistrer(
                $inscription,
                "Inscription de l'élève #{$eleveId} en classe #{$classeId}, en attente de versement",
            );

            // 4. Générer + envoyer automatiquement la facture provisoire.
            $this->factureService->genererProvisoire($inscription->id);

            return $inscription->id;
        });
    }

    public function preparerEtInscrire(?int $eleveId, array $eleve, ?int $parentId, array $parent, string $lienParente, int $classeId, int $anneeScolaireId, array $fraisDiversIds = []): int
    {
        return DB::transaction(function () use ($eleveId, $eleve, $parentId, $parent, $lienParente, $classeId, $anneeScolaireId, $fraisDiversIds): int {
            $dossierEleve = $eleveId
                ? Eleve::query()->findOrFail($eleveId)
                : Eleve::query()->create([...$eleve, 'statut' => 'prospect']);

            $dossierParent = $parentId
                ? ParentTuteur::query()->findOrFail($parentId)
                : ParentTuteur::query()->create([...$parent, 'portail_actif' => true]);

            $dossierEleve->parentsTuteurs()->syncWithoutDetaching([
                $dossierParent->id => [
                    'lien' => $lienParente,
                    'responsable_legal' => true,
                    'responsable_paiement' => true,
                    'autorise_recuperation' => true,
                ],
            ]);

            return $this->inscrire($dossierEleve->id, $classeId, $anneeScolaireId, $fraisDiversIds);
        });
    }

    public function activerApresVersement(int $inscriptionId): void
    {
        DB::transaction(function () use ($inscriptionId): void {
            $inscription = Inscription::query()->lockForUpdate()->findOrFail($inscriptionId);

            if ($inscription->statut === 'active') {
                return;
            }

            $eleve = Eleve::query()->lockForUpdate()->findOrFail($inscription->eleve_id);
            $eleve->statut = 'actif';
            $eleve->save();

            $inscription->update(['statut' => 'active']);

            // Routinier — enregistrer(), pas enregistrerAvecMotif().
            $this->auditService->enregistrer($inscription, 'Inscription activée après confirmation du versement');

            $this->factureService->genererDefinitive($inscriptionId);
        });
    }

    public function annulerInscription(int $inscriptionId, string $motif): void
    {
        if (trim($motif) === '') {
            throw new MotifAnnulationRequisException;
        }

        DB::transaction(function () use ($inscriptionId, $motif): void {
            $inscription = Inscription::query()->lockForUpdate()->findOrFail($inscriptionId);

            $inscription->update(['statut' => 'annulee']);

            // Les frais encore dus ne comptent plus une fois l'inscription
            // annulée. Les paiements déjà encaissés ne sont jamais touchés
            // ici — leur éventuelle annulation/remboursement reste une
            // action distincte et explicite (PaiementServiceContract::annulerPaiement()).
            FraisEleve::where('inscription_id', $inscriptionId)
                ->where('statut', 'du')
                ->update(['statut' => 'annule']);

            // Véritable annulation avec motif obligatoire — enregistrerAvecMotif().
            $this->auditService->enregistrerAvecMotif($inscription, "Inscription annulée : {$motif}", $motif);
        });
    }

    public function estInscrit(int $eleveId, int $anneeScolaireId): bool
    {
        return Inscription::where('eleve_id', $eleveId)
            ->where('annee_scolaire_id', $anneeScolaireId)
            ->whereIn('statut', ['en_attente_versement', 'active'])
            ->exists();
    }

    public function getFraisRestants(int $inscriptionId): float
    {
        // Résolu paresseusement (et non injecté au constructeur) : Paiement
        // Service dépend lui-même d'InscriptionServiceInterface pour
        // déclencher activerApresVersement() — une injection croisée au
        // constructeur créerait une dépendance circulaire au moment de la
        // résolution par le conteneur.
        return app(PaiementServiceContract::class)->getResteAPayer($inscriptionId);
    }
}
