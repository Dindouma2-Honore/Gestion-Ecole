<?php

declare(strict_types=1);

namespace App\Modules\Scolarite\Services;

use App\Modules\Scolarite\Contracts\EleveServiceInterface;
use App\Modules\Scolarite\Exceptions\EleveIntrouvableException;
use App\Modules\Scolarite\Models\Eleve;
use App\Modules\Socle\Contracts\ParametrageServiceContract;

class EleveService implements EleveServiceInterface
{
    public function __construct(
        private readonly ParametrageServiceContract $parametrageService,
    ) {}

    public function existe(int $eleveId): bool
    {
        return Eleve::whereKey($eleveId)->exists();
    }

    public function getEleve(int $eleveId): array
    {
        $eleve = Eleve::with('inscriptions')->find($eleveId);

        if (! $eleve) {
            throw EleveIntrouvableException::pourId($eleveId);
        }

        $inscriptionActive = $eleve->inscriptions->firstWhere('statut', 'active');

        return [
            'id' => $eleve->id,
            'nom' => $eleve->nom,
            'prenom' => $eleve->prenom,
            'classe_id' => $inscriptionActive?->classe_id,
        ];
    }

    public function creer(array $donnees): array
    {
        // Le matricule est attribué automatiquement à la création (voir
        // Eleve::booted()) — jamais saisi ici, jamais régénéré ensuite.
        $eleve = Eleve::create([
            'nom' => $donnees['nom'],
            'prenom' => $donnees['prenom'],
            'date_naissance' => $donnees['date_naissance'] ?? null,
            'sexe' => $donnees['sexe'] ?? null,
            'photo' => $donnees['photo'] ?? null,
            'statut' => 'prospect',
        ]);

        return $eleve->toArray();
    }

    public function genererMatricule(): string
    {
        // Numérotation déléguée à Socle (ParametrageServiceContract) —
        // NumerotationService::next() ouvre déjà sa propre transaction avec
        // verrou pessimiste sur la ligne formats_numerotation concernée,
        // donc thread-safe même appelé isolément depuis Eleve::booted()
        // (static::creating), en dehors de toute transaction explicite.
        return $this->parametrageService->genererNumero('matricule_eleve');
    }

    public function getNiveauId(int $eleveId): int
    {
        $eleve = Eleve::with(['inscriptions' => fn ($query) => $query->where('statut', 'active')->with('classe')])
            ->find($eleveId);

        if (! $eleve) {
            throw EleveIntrouvableException::pourId($eleveId);
        }

        $niveauId = $eleve->inscriptions->first()?->classe?->niveau_id;

        if ($niveauId === null) {
            throw EleveIntrouvableException::pourId($eleveId);
        }

        return (int) $niveauId;
    }

    public function getElevesActifsIds(?int $niveauId = null): array
    {
        return Eleve::query()
            ->where('statut', 'actif')
            ->when($niveauId !== null, fn ($query) => $query->whereHas(
                'inscriptions.classe',
                fn ($classe) => $classe->where('niveau_id', $niveauId),
            ))
            ->pluck('id')
            ->map(fn ($id): int => (int) $id)
            ->all();
    }

    public function getElevesParClasse(int $classeId): array
    {
        return Eleve::whereHas('inscriptions', fn ($q) => $q
                ->where('classe_id', $classeId)
                ->whereIn('statut', ['en_attente_versement', 'active']))
            ->get()
            ->map(fn (Eleve $e) => ['id' => $e->id, 'nom' => $e->nom, 'prenom' => $e->prenom])
            ->all();
    }
}
